"""Project configuration."""
