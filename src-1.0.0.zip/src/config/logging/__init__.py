"""Log configuration package."""
