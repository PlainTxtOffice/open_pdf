"""Public entry point for the desktop GUI."""

from src.gui.views.root_window.window import MainWindow

__all__ = ["MainWindow"]
