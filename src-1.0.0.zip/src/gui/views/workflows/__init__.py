"""Presentation workflows driven from the main viewer window."""
