"""Menu bar and dropdown menu helpers for the PySide6 GUI."""
