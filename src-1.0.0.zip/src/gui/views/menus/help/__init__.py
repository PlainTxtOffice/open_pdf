"""Help menu and dialog helpers for the PySide6 GUI."""
