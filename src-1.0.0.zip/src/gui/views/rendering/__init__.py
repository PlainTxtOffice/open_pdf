"""Rendering helpers for the PySide6 GUI."""
