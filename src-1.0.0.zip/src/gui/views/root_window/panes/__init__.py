"""Side pane views hosted by the main window."""
