"""Main viewer window package."""
