"""Qt view packages for the desktop viewer."""
