"""Modal and modeless dialog views."""
