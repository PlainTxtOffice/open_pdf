"""Mutable and persisted state owned by the GUI shell."""
