"""OCR presentation package."""
