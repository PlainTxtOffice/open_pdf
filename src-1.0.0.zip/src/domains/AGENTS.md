# Domain/Business

- business and domain code and logic
- no api logic
- no io
- purely domain code
