"""Domain layer packages for document behavior."""
