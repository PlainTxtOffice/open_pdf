"""PDF domain models and the reader that loads, edits, and saves them."""
