"""Page-scoped document operations."""
