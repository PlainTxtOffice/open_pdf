"""Page text extraction, OCR, and search."""
