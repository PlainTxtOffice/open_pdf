"""Document-level properties: outlines and notes."""
