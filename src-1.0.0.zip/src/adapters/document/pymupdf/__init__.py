"""PyMuPDF-backed document adapters."""
