"""PyMuPDF-backed document content adapters."""
