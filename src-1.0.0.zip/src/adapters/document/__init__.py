"""Document filesystem and PDF integration adapters."""
