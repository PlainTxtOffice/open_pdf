"""Desktop preference and credential persistence adapters."""
