"""Desktop process runtime adapters."""
