"""OCR engine and result persistence adapters."""
