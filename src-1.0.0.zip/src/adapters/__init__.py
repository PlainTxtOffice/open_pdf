"""Infrastructure adapters that bridge app code to external libraries."""
