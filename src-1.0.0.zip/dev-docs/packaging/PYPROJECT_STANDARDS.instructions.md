# Pyproject Standards

This document defines the repository standard for maintaining `pyproject.toml`.

## Why this exists

`pyproject.toml` should be treated as the canonical source for build metadata. Keeping this file accurate improves reproducibility, publishing safety, and tooling compatibility.

## Update policy

If `pyproject.toml` does not yet exist, create it with at minimum a `[build-system]` table and a `[project]` table containing `name`, `version`, `requires-python`, and `dependencies` before applying any of the update rules below.

When a change affects any of the following, update `pyproject.toml` in the same change:

- Runtime dependencies
- Optional dependencies / extras
- Dependency groups
- Python version support
- Entry points / scripts
- Build backend or build requirements
- License expression or license file declarations

If `requirements.txt` is present, it must list the same packages and version specifiers as `[project.dependencies]` in `pyproject.toml`. Optional dependencies and dependency groups are not required to appear in `requirements.txt` unless a separate extras-pinned file exists for them.

## Standards to follow

- **PEP 518**: `[build-system]` table (`requires`, `build-backend`)
- **PEP 621**: `[project]` core metadata (`name`, `version`, `requires-python`, `dependencies`, `optional-dependencies`, `scripts`, etc.)
- **PEP 639**: `license` expression and `license-files`
- **PyPA Dependency Groups specification**: `[dependency-groups]` when used

## Nuitka Packaging Scripts

When this repository includes Nuitka packaging automation, keep the
packaging scripts as PowerShell files in `dev-docs/packaging/nuitka/`.

- Keep one script for standalone builds.
- Keep one script for onefile builds.
- Prefer clear names such as `standalone.ps1` and `onefile.ps1`.

## Practical checklist

Before completing a packaging-related change:

1. Confirm `[build-system]` is correct for the chosen backend.
2. Confirm `[project]` metadata reflects the current project state.
3. Confirm `requires-python` matches supported runtime versions.
4. Confirm dependency lists are accurate and normalized to PEP 508 strings.
  Use version ranges (`>=x.y,<x+1`) for library packages and exact pins (`==x.y.z`) only for application deployments or lock files. Do not leave dependencies unpinned unless the package intentionally accepts any version.
5. Confirm `license` / `license-files` are valid and complete.
6. Confirm scripts/entry points still match actual callable paths.
7. If present, confirm `requirements.txt` is in sync with `pyproject.toml` intent.

## Canonical references

- [PyPA packaging guide](https://packaging.python.org/)
- [`pyproject.toml` specification](https://packaging.python.org/en/latest/specifications/pyproject-toml/)
- [Writing `pyproject.toml`](https://packaging.python.org/en/latest/guides/writing-pyproject-toml/)
- [Dependency groups](https://packaging.python.org/en/latest/specifications/dependency-groups/)
- [PEP 518](https://peps.python.org/pep-0518/)
- [PEP 621](https://peps.python.org/pep-0621/)
- [PEP 639](https://peps.python.org/pep-0639/)
