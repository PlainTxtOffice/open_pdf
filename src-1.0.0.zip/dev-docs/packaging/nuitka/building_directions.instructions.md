---
last_updated: 2026-03-23
version: 1.5.0
---

# Building Directions

## Agent Task

When this repository needs local Nuitka packaging automation, create two
PowerShell build scripts in `dev-docs/packaging/nuitka/` following the
repository packaging pattern documented here.

Apply the guidance in this order when it overlaps: keep established
repository conventions first, follow the required script structure and
runtime-safety rules next, and use naming preferences only when the
repository does not already establish a different convention.

- keep one script for standalone builds
- keep one script for onefile builds
- prefer clear names such as `standalone.ps1` and `onefile.ps1`

If the repository already uses another established naming convention,
keep the existing naming rather than renaming for style alone.

Use the repository's default `.venv` as the build interpreter unless
the project explicitly specifies a different build environment in
`pyproject.toml`, `README.md`, or nearby packaging documentation.

If neither `.venv` nor explicit build-environment documentation is
available, ask the user which Python interpreter should run the build
scripts before creating or changing them.

Check `pyproject.toml` for project metadata, such as reading the package name or a project-specific
`[tool.*]` setting. Do not treat the general pyproject standards guide
as the source of Nuitka build behavior.

Use this working order to keep the task small and consistent:

1. identify the build interpreter and project metadata
2. adapt script names and output defaults to existing repository conventions
3. apply the shared script shape and mode-specific Nuitka flags
4. add runtime-default handling only when the repository already has a real configuration contract

## Required Script Shape

Both scripts should follow the same operational structure.

1. Use `[CmdletBinding()]` and an explicit `param(...)` block.
2. Accept a Python executable path parameter with a default of
   `.venv/Scripts/python.exe`.
3. Accept output directory and output filename parameters.
4. Set the default output filename to the project title, not the module
   or entrypoint filename.
5. Avoid generic executable names such as `main.exe`, `app.exe`, or
   `program.exe` when the real project title is available.
6. Resolve the repository root from `$PSScriptRoot` instead of assuming
   the current working directory.
7. Join the Python executable path against the repository root and fail
   fast if the interpreter does not exist.
8. Build a `$nuitkaArguments` array and invoke Nuitka with
   `& $pythonPath @nuitkaArguments`.
9. Use `Push-Location` / `Pop-Location` around the build so relative
   paths resolve from the repo root.
10. Set `$ErrorActionPreference = "Stop"`.
11. Throw a clear error if Nuitka exits with a non-zero exit code.
12. Print a few `Write-Host` or `Write-Warning` messages describing what
    the script is building and which runtime defaults are being bundled.

If the agent is creating the scripts for the first time, default to the
repository's `.venv` as the build interpreter.

## Shared Parameters

Unless the project has a better-established contract, give both scripts
the same parameter surface:

- `PythonExecutable`
- `OutputDirectory`
- `OutputFilename`
- `UseCurrentDefaultPaths`
- `ResetRuntimeDefaults`

Keep switch parameters as switches, not boolean positional parameters.

Document in comments or nearby packaging docs how to override
`PythonExecutable` if a different interpreter is needed.

## Shared Nuitka Flags

Start both scripts from the same baseline flags and then vary only the
mode-specific option.

Include these flags unless the current project has a verified reason not
to:

- `-m nuitka`
- `--enable-plugin=pyside6` when the app uses PySide6
- `--windows-console-mode=disable` for GUI applications
- `--windows-icon-from-ico=assets/<name>.ico` when an `.ico` file
  exists in `assets/`
- `--msvc=latest`
- `--output-filename=...`
- `--output-dir=...`
- `--assume-yes-for-downloads`
- `src/main.py` as the entrypoint when this repository still uses the
  thin-entrypoint pattern

Keep Nuitka's intermediate build directories by default so subsequent
builds can reuse unchanged output. Add `--remove-output` only when a clean
post-build directory is explicitly required.

Then add exactly one of these per script:

- standalone script: `--standalone`
- onefile script: `--onefile`

Use the selected build interpreter to run Nuitka.

## Runtime Defaults Pattern

The reference scripts bundle a release-safe defaults file rather than
blindly packaging the developer's live settings. Reuse that pattern when
this project has writable runtime settings or path defaults.

Implementation rules:

1. Determine a release-input directory under `build/`, such as
   `build/nuitka-inputs`.
2. If `UseCurrentDefaultPaths` is not set, create a small JSON file in
   that build input directory containing blank or null defaults.
3. Use `--include-data-files=` to bundle that release-safe JSON into the
   runtime location expected by the application.
4. If `UseCurrentDefaultPaths` is set, bundle the current repository
   defaults file instead and emit a warning.
5. If `ResetRuntimeDefaults` is set, delete the persisted runtime
   defaults file from the user profile before building.
6. If persisted runtime defaults already exist and are not being reset,
   warn that local smoke tests may still read those persisted values.

Adapt the bundled defaults file content and runtime settings path to the
current project's real configuration contract.

Do not copy product-specific JSON keys, application names, or OS-specific
user-data locations from another repository. Keep the structure of the
pattern, but derive the actual defaults file shape and storage paths from
the current project.

If the current repository does not yet have runtime default-path
handling, omit this feature rather than inventing speculative settings
files.

## Base Root Pattern

When the application needs stable relative paths in both Python
development and a compiled executable, keep both base roots in
`src/config/path_handler.py` and derive the public `ROOT_DIR` from the
active runtime mode.

Preferred pattern:

```python
import os
import sys
from pathlib import Path

IS_COMPILED = bool(
    globals().get("__compiled__", False) or getattr(sys, "frozen", False)
)
DEV_ROOT = Path(__file__).resolve().parents[2]
PACKAGED_ROOT = (
    Path(os.environ.get("LOCALAPPDATA", Path.home())) / "Example App"
)

ROOT_DIR = DEV_ROOT
USER_STORAGE_ROOT = PACKAGED_ROOT if IS_COMPILED else DEV_ROOT
```

Use `DEV_ROOT` for repository-relative development paths and
`USER_STORAGE_ROOT` for writable packaged runtime paths. Keep `ROOT_DIR`
for read-only repository assets, and derive persisted `data/` and `logs/`
paths from `USER_STORAGE_ROOT`.

## Persisted User Data Discovery

Before creating the build scripts, the agent must determine whether the
application should keep using the repository's `data/` directory for
persistent storage or switch to a system-managed user data path.

At this decision point, ask the user which storage model they want for
this project before changing code, paths, or packaging behavior. Use the
default rule below only to frame the question or to guide a proposal,
not to skip the question.

Recommended question shape:

1. keep persistence in repository-local `data/`, including compiled
   personal-use builds
2. use a system-managed per-user app-data folder for installed or
   publicly distributed builds

Use this decision rule unless the user says otherwise:

1. use repository-local `data/` for personal-use programs, including
   compiled builds that the user mainly runs for themselves, when
   keeping the writable data beside the program is intentional
2. use a system-managed per-user data folder for publicly distributed,
   commercial, or production-facing applications that need durable
   writable state outside the source tree or installed program folder

The main decision is product audience, not compilation by itself.
Compiled does not automatically mean system-managed user storage.

When this document says system-managed user data path, it means a
writable per-user application data location such as `%LOCALAPPDATA%`
or a `platformdirs`-resolved equivalent. It does not mean writing user
data into `Program Files` or next to protected installed program files.

If the repository already persists data under `data/`, ask the user
which model they want to keep for this project:

1. continue using the repository `data/` directory
2. move persistent storage to a system path such as a per-user app-data
   directory

If the repository already uses a system-managed user data path, ask
whether that behavior should remain in place or be intentionally changed.

Do not silently migrate persistence behavior during packaging work.

For personal programs that the user is building mainly for themselves,
keeping persistent files under the repository-local `data/` directory is
an acceptable default, including in compiled builds, when that simpler
layout is intentional. For commercial or production-facing desktop
applications distributed to the public, a system-managed per-user data
folder is usually the better default. Treat that as a product decision
to confirm with the user, not a migration to apply implicitly.

After that decision is clear, check whether the application already
writes persistent data to a user-profile directory.

Search the source for calls to `platformdirs`, `appdirs`,
`os.getenv("LOCALAPPDATA")`, `os.getenv("APPDATA")`, `Path.home()`,
or any other user-directory resolution.

If the user chooses to keep repository-local persistence under `data/`:

1. keep that behavior unchanged
2. do not introduce `app-data-dir` metadata just for packaging
3. do not add user-profile cleanup logic to the build scripts
4. warn only about repository-local test data when that could affect
   smoke testing

If a persistent storage path is found:

1. Ensure the application exposes the path as a constant in
   `path_handler.py` (e.g. `USER_DATA_DIR`). This is the canonical
   source the application code should import from.
2. Record the directory name in `pyproject.toml` under the project's
   own `[tool.<project-name>]` table with an `app-data-dir` key so
   build scripts and future agents can locate it without reading Python
   source:

```toml
[tool.example_app]
app-data-dir = "Example App"
```

The `path_handler.py` module should read this value at startup and
fall back to a hardcoded default when `pyproject.toml` is not on disk
(e.g. inside a Nuitka build).

If these already exist, use the values from them instead of
re-scanning the source.

The build scripts should then:

1. Read the `app-data-dir` value from the project's `[tool.*]` table
   in `pyproject.toml`.
2. If the path is set, emit a `Write-Warning` at the start of the
   build noting the path and that stale data from earlier runs may
   affect smoke testing.
3. If the `ResetRuntimeDefaults` switch is provided, delete or rename
   that directory before building so the smoke test starts clean.
4. Never silently delete user data without an explicit switch.

## Onefile-Specific Requirement

Mirror the reference onefile script's compression preflight.

Before invoking Nuitka in onefile mode:

1. run the selected interpreter with `-c "import zstandard"`
2. fail with a clear installation message if that import fails
3. explain that compressed onefile builds require the `zstandard`
   support from `Nuitka[onefile]`

Keep this validation only in the onefile script.

## Project Adaptation Rules

The agent should copy the structure of the reference scripts, not their
product-specific literals.

Adapt these values to the current repository:

- application icon — look for an `.ico` file in `assets/`
- executable name
- output directory names
- runtime settings file path
- bundled JSON path
- GUI plugin choice
- entrypoint path when it is not `src/main.py`

Prefer deriving the executable name from project metadata or existing
packaging docs when available.

When a project title or distribution name is known, use that title for
`OutputFilename`, for example `ProjectTitle.exe`, instead of generic names
derived from the entrypoint such as `main.exe`.

## Nuitka Build Comments in Source Files

If any Python source files in the repository contain inline Nuitka
project configuration comments (lines matching `# nuitka-project:` or
`# nuitka-project-if:`), the agent must delete those comment lines.

All Nuitka flags belong in the build scripts, not embedded in
application source code. Inline project comments create a hidden second
source of build configuration that conflicts with the centralized
scripts this pattern establishes.

## Delivery Expectation

When creating these scripts, the agent should also:

1. keep the scripts focused on packaging only
2. avoid moving application logic into the scripts
3. update nearby packaging documentation if the final script names or
   invocation examples need to be recorded
4. verify the scripts at least for syntax and obvious path mistakes
5. remove any `# nuitka-project:` or `# nuitka-project-if:` comments
   from Python source files in the repository

The target outcome is a pair of small, readable PowerShell entrypoints
that share the same structure, differ mainly by `--standalone` versus
`--onefile`, and preserve the release-safety behavior from the
reference implementation where that behavior is relevant to the current
project
