[CmdletBinding()]
param(
    [string]$PythonExecutable = ".venv/Scripts/python.exe",
    [string]$OutputDirectory = "build/standalone",
    [string]$OutputFilename = "Open PDF.exe",
    [ValidateSet("msvc", "clang", "mingw64")]
    [string]$Compiler = "clang",
    [string]$MsvcVersion = "latest",
    [ValidateRange(1, 64)]
    [int]$Jobs = 1,
    [ValidateSet("yes", "no", "auto")]
    [string]$Lto = "no",
    [switch]$UseCurrentDefaultPaths,
    [switch]$ResetRuntimeDefaults,
    [switch]$ShowBackendCommands,
    [switch]$DisableLowMemory,
    [switch]$FasterBackendRetry
)

$ErrorActionPreference = "Stop"

function Resolve-RepoPath {
    param(
        [Parameter(Mandatory)]
        [string]$RepositoryRoot,

        [Parameter(Mandatory)]
        [string]$PathValue
    )

    if ([System.IO.Path]::IsPathRooted($PathValue)) {
        return $PathValue
    }

    return (Join-Path $RepositoryRoot $PathValue)
}

function Test-ClangCompiler {
    if (Get-Command "clang-cl.exe" -ErrorAction SilentlyContinue) {
        return $true
    }

    $programFilesX86 = [Environment]::GetFolderPath("ProgramFilesX86")
    $vswherePath = Join-Path $programFilesX86 "Microsoft Visual Studio\Installer\vswhere.exe"

    if (-not (Test-Path $vswherePath)) {
        return $false
    }

    $installPaths = & $vswherePath -products * -property installationPath
    foreach ($installPath in $installPaths) {
        $clangPath = Join-Path $installPath "VC\Tools\Llvm\x64\bin\clang-cl.exe"
        if (Test-Path $clangPath) {
            return $true
        }
    }

    return $false
}

$repoRoot = (Resolve-Path (Join-Path $PSScriptRoot "..\..\..")).Path
$pythonPath = Resolve-RepoPath -RepositoryRoot $repoRoot -PathValue $PythonExecutable
$resolvedOutputDirectory = Resolve-RepoPath -RepositoryRoot $repoRoot -PathValue $OutputDirectory
$entryPoint = Join-Path $repoRoot "src/main.py"
$pyprojectPath = Join-Path $repoRoot "pyproject.toml"
$dataDirectory = Join-Path $repoRoot "data"
$buildReportPath = Join-Path $resolvedOutputDirectory "compilation-report.xml"
$assetsDirectory = Join-Path $repoRoot "assets"
$iconPath = Join-Path $repoRoot "assets/app.ico"

if (-not (Test-Path $pythonPath)) {
    throw "Python interpreter not found at '$pythonPath'. Override -PythonExecutable if this repository should build with another interpreter."
}

if (-not (Test-Path $entryPoint)) {
    throw "Expected entrypoint not found at '$entryPoint'."
}

if (-not (Test-Path $pyprojectPath)) {
    throw "Project metadata not found at '$pyprojectPath'."
}

$metadataCommand = (
    "import pathlib, sys, tomllib; " +
    "project = tomllib.loads(pathlib.Path(sys.argv[1]).read_text(encoding='utf-8'))['project']; " +
    "print(project['version']); print(' '.join(project['description'].split()))"
)
$projectMetadata = @(& $pythonPath -c $metadataCommand $pyprojectPath)
if ($LASTEXITCODE -ne 0 -or $projectMetadata.Count -ne 2) {
    throw "Could not read version and description from '$pyprojectPath'."
}

$projectVersion = $projectMetadata[0].Trim()
$projectDescription = $projectMetadata[1].Trim()
if ($projectVersion -notmatch '^\d+(\.\d+){1,3}$') {
    throw "Project version '$projectVersion' is not valid Windows version metadata."
}

# This metadata is compiled into the executable's version resource, so
# template placeholders would ship to end users.
foreach ($metadataValue in @($projectVersion, $projectDescription)) {
    if ($metadataValue -match 'replace-me') {
        throw "Project metadata '$metadataValue' is still a pyproject.toml placeholder. Set a real project version and description before building."
    }
}

$companyName = "Plain Txt Office"
$productName = "Open PDF"
$copyrightNotice = "Copyright (c) 2026 Plain Txt Office"

$pythonVersion = (& $pythonPath -c "import sys; print(f'{sys.version_info.major}.{sys.version_info.minor}')").Trim()
if ([version]$pythonVersion -ge [version]"3.14") {
    Write-Warning "Nuitka currently treats Python $pythonVersion as experimental. If PyMuPDF compilation fails, prefer a 3.13 interpreter via -PythonExecutable."
}

if ($UseCurrentDefaultPaths.IsPresent) {
    Write-Warning "-UseCurrentDefaultPaths has no effect; packaged builds use per-user application data paths."
}

if ($ResetRuntimeDefaults.IsPresent) {
    Write-Warning "-ResetRuntimeDefaults has no effect for this project because there is no separate persisted user-profile defaults file to clear."
}

if ((Test-Path $dataDirectory) -and @(Get-ChildItem -Force -ErrorAction SilentlyContinue $dataDirectory).Count -gt 0) {
    Write-Warning "Repository-local data exists under '$dataDirectory'. Local smoke tests may read that data."
}

if ($Compiler -ne "msvc" -and $MsvcVersion -ne "latest") {
    Write-Warning "-MsvcVersion is ignored when -Compiler is '$Compiler'."
}

if ($Compiler -eq "mingw64" -and [version]$pythonVersion -ge [version]"3.13") {
    throw "Nuitka cannot use MinGW64 with Python $pythonVersion. Use -Compiler msvc, try -Lto yes, or install Visual Studio's clang component and use -Compiler clang."
}

if ($Compiler -eq "clang" -and -not (Test-ClangCompiler)) {
    throw "Visual Studio clang-cl was not found. Install Visual Studio's clang component, then rerun this script with -Compiler clang."
}

if ($FasterBackendRetry.IsPresent) {
    if (-not $PSBoundParameters.ContainsKey("ShowBackendCommands")) {
        $ShowBackendCommands = $true
    }

    if (-not $PSBoundParameters.ContainsKey("Jobs")) {
        $Jobs = 4
    }

    if (-not $PSBoundParameters.ContainsKey("DisableLowMemory")) {
        $DisableLowMemory = $true
    }
}

if ($Jobs -gt 1 -and -not $DisableLowMemory.IsPresent) {
    Write-Warning (
        "Using -Jobs $Jobs while keeping --low-memory may still limit backend concurrency. " +
        "If the machine has enough RAM, add -DisableLowMemory for a faster retry."
    )
}

New-Item -ItemType Directory -Force -Path $resolvedOutputDirectory | Out-Null

$compilerArguments = switch ($Compiler) {
    "msvc" { @("--msvc=$MsvcVersion") }
    "clang" { @("--clang") }
    "mingw64" { @("--mingw64") }
}

$compilerDescription = switch ($Compiler) {
    "msvc" { "MSVC $MsvcVersion" }
    "clang" { "clang-cl from Visual Studio" }
    "mingw64" { "MinGW64" }
}

$nuitkaArguments = @(
    "-m",
    "nuitka",
    "--standalone",
    "--enable-plugin=pyside6",
    "--windows-console-mode=disable",
    "--company-name=$companyName",
    "--product-name=$productName",
    "--file-version=$projectVersion",
    "--product-version=$projectVersion",
    "--file-description=$projectDescription",
    "--copyright=$copyrightNotice",
    "--jobs=$Jobs",
    "--lto=$Lto",
    "--output-filename=$OutputFilename",
    "--output-dir=$resolvedOutputDirectory",
    "--assume-yes-for-downloads",
    "--report=$buildReportPath",
    "src/main.py"
)

$nuitkaArguments += $compilerArguments

if (-not $DisableLowMemory.IsPresent) {
    $nuitkaArguments += "--low-memory"
}

if (Test-Path $iconPath) {
    $nuitkaArguments += "--windows-icon-from-ico=$iconPath"
}

if (Test-Path $assetsDirectory) {
    $nuitkaArguments += "--include-data-dir=$assetsDirectory=assets"
}

if ($ShowBackendCommands.IsPresent) {
    $nuitkaArguments += "--show-scons"
}

Write-Host "Building standalone Open PDF executable"
Write-Host "Python interpreter: $pythonPath"
Write-Host "Output directory: $resolvedOutputDirectory"
Write-Host "Runtime data model: packaged builds use %LOCALAPPDATA%\Open PDF"
Write-Host "C compiler: $compilerDescription"
Write-Host (
    "Compilation mode: " +
    $(if ($DisableLowMemory.IsPresent) { "standard-memory" } else { "low-memory" }) +
    ", jobs=$Jobs, LTO=$Lto for PyMuPDF-heavy builds"
)
if ($ShowBackendCommands.IsPresent) {
    Write-Host "Backend command logging: enabled via --show-scons"
}
if ($FasterBackendRetry.IsPresent) {
    Write-Host "Backend retry preset: enabled (defaults to show commands, jobs=4, low-memory disabled unless overridden)"
}

Push-Location $repoRoot
try {
    & $pythonPath @nuitkaArguments
    if ($LASTEXITCODE -ne 0) {
        throw "Nuitka standalone build failed with exit code $LASTEXITCODE."
    }
}
finally {
    Pop-Location
}
