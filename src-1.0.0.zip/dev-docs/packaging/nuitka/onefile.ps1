[CmdletBinding()]
param(
    [string]$PythonExecutable = ".venv/Scripts/python.exe",
    [string]$OutputDirectory = "build/onefile",
    [string]$OutputFilename = "Open PDF.exe",
    [ValidateSet("msvc", "clang", "mingw64")]
    [string]$Compiler = "clang",
    [string]$MsvcVersion = "latest",
    [ValidateRange(1, 64)]
    [int]$Jobs = 1,
    [ValidateSet("yes", "no", "auto")]
    [string]$Lto = "no",
    [switch]$StopRunningOutput,
    [switch]$NoStopRunningOutput,
    [switch]$UseCurrentDefaultPaths,
    [switch]$ResetRuntimeDefaults,
    [switch]$ShowBackendCommands,
    [switch]$DisableLowMemory,
    [switch]$FasterBackendRetry
)

$ErrorActionPreference = "Stop"

if (-not $PSBoundParameters.ContainsKey("FasterBackendRetry")) {
    $FasterBackendRetry = $true
}

if (-not $PSBoundParameters.ContainsKey("StopRunningOutput") -and -not $NoStopRunningOutput.IsPresent) {
    $StopRunningOutput = $true
}

function Resolve-RepoPath {
    param(
        [Parameter(Mandatory)]
        [string]$RepositoryRoot,

        [Parameter(Mandatory)]
        [string]$PathValue
    )

    if ([System.IO.Path]::IsPathRooted($PathValue)) {
        return $PathValue
    }

    return (Join-Path $RepositoryRoot $PathValue)
}

function Test-ClangCompiler {
    if (Get-Command "clang-cl.exe" -ErrorAction SilentlyContinue) {
        return $true
    }

    $programFilesX86 = [Environment]::GetFolderPath("ProgramFilesX86")
    $vswherePath = Join-Path $programFilesX86 "Microsoft Visual Studio\Installer\vswhere.exe"

    if (-not (Test-Path $vswherePath)) {
        return $false
    }

    $installPaths = & $vswherePath -products * -property installationPath
    foreach ($installPath in $installPaths) {
        $clangPath = Join-Path $installPath "VC\Tools\Llvm\x64\bin\clang-cl.exe"
        if (Test-Path $clangPath) {
            return $true
        }
    }

    return $false
}

function Get-ProcessesByExactPath {
    param(
        [Parameter(Mandatory)]
        [string]$ExecutablePath
    )

    return @(Get-Process -ErrorAction SilentlyContinue | Where-Object {
            try {
                $_.Path -eq $ExecutablePath
            }
            catch {
                $false
            }
        })
}

function Stop-ProcessesByExactPath {
    param(
        [Parameter(Mandatory)]
        [string]$ExecutablePath
    )

    $matchingProcesses = Get-ProcessesByExactPath -ExecutablePath $ExecutablePath
    if ($matchingProcesses.Count -eq 0) {
        return @()
    }

    $processIds = @($matchingProcesses | ForEach-Object { $_.Id })
    Stop-Process -Id $processIds -Force -ErrorAction Stop

    foreach ($processId in $processIds) {
        try {
            Wait-Process -Id $processId -Timeout 10 -ErrorAction Stop
        }
        catch [Microsoft.PowerShell.Commands.ProcessCommandException] {
            continue
        }
    }

    return $processIds
}

function Invoke-LoggedBuildWithProgress {
    param(
        [Parameter(Mandatory)]
        [string]$ExecutablePath,

        [Parameter(Mandatory)]
        [string[]]$ArgumentList,

        [Parameter(Mandatory)]
        [string]$WorkingDirectory,

        [Parameter(Mandatory)]
        [string]$LogPath,

        [Parameter(Mandatory)]
        [string]$Activity
    )

    $processStartInfo = [System.Diagnostics.ProcessStartInfo]::new()
    $processStartInfo.FileName = $ExecutablePath
    $processStartInfo.WorkingDirectory = $WorkingDirectory
    $processStartInfo.UseShellExecute = $false
    $processStartInfo.RedirectStandardOutput = $true
    $processStartInfo.RedirectStandardError = $true
    foreach ($argument in $ArgumentList) {
        [void]$processStartInfo.ArgumentList.Add($argument)
    }

    $buildProcess = [System.Diagnostics.Process]::new()
    $buildProcess.StartInfo = $processStartInfo
    $buildProcess.Start() | Out-Null

    $standardOutputTask = $buildProcess.StandardOutput.ReadToEndAsync()
    $standardErrorTask = $buildProcess.StandardError.ReadToEndAsync()
    $stopwatch = [System.Diagnostics.Stopwatch]::StartNew()

    try {
        while (-not $buildProcess.WaitForExit(1000)) {
            $elapsed = $stopwatch.Elapsed.ToString("hh\:mm\:ss")
            Write-Progress -Id 1 -Activity $Activity -Status "Elapsed $elapsed" -CurrentOperation "Nuitka build running"
        }

        $buildProcess.WaitForExit()

        $standardOutput = $standardOutputTask.GetAwaiter().GetResult().TrimEnd()
        $standardError = $standardErrorTask.GetAwaiter().GetResult().TrimEnd()
        $capturedOutput = @()
        if ($standardOutput) {
            $capturedOutput += $standardOutput
        }
        if ($standardError) {
            $capturedOutput += $standardError
        }
        Set-Content -Path $LogPath -Value $capturedOutput

        return $buildProcess.ExitCode
    }
    finally {
        Write-Progress -Id 1 -Activity $Activity -Completed
        $buildProcess.Dispose()
    }
}

function Format-BuildTimestamp {
    param(
        [Parameter(Mandatory)]
        [datetime]$Timestamp
    )

    return $Timestamp.ToString("yyyy-MM-dd HH:mm:ss")
}

$repoRoot = (Resolve-Path (Join-Path $PSScriptRoot "..\..\..")).Path
$pythonPath = Resolve-RepoPath -RepositoryRoot $repoRoot -PathValue $PythonExecutable
$resolvedOutputDirectory = Resolve-RepoPath -RepositoryRoot $repoRoot -PathValue $OutputDirectory
$resolvedOutputExecutable = Join-Path $resolvedOutputDirectory $OutputFilename
$buildLogPath = Join-Path $resolvedOutputDirectory "nuitka-onefile-build.log"
$buildReportPath = Join-Path $resolvedOutputDirectory "compilation-report.xml"
$entryPoint = Join-Path $repoRoot "src/main.py"
$pyprojectPath = Join-Path $repoRoot "pyproject.toml"
$iconPath = Join-Path $repoRoot "assets/app.ico"
$assetsDirectory = Join-Path $repoRoot "assets"
$portableMarkerPath = Join-Path $repoRoot "dev-docs/packaging/nuitka/portable.marker"

if (-not (Test-Path $pythonPath)) {
    throw "Python interpreter not found at '$pythonPath'. Override -PythonExecutable if this repository should build with another interpreter."
}

if (-not (Test-Path $entryPoint)) {
    throw "Expected entrypoint not found at '$entryPoint'."
}

if (-not (Test-Path $pyprojectPath)) {
    throw "Project metadata not found at '$pyprojectPath'."
}

$metadataCommand = (
    "import pathlib, sys, tomllib; " +
    "project = tomllib.loads(pathlib.Path(sys.argv[1]).read_text(encoding='utf-8'))['project']; " +
    "print(project['version']); print(' '.join(project['description'].split()))"
)
$projectMetadata = @(& $pythonPath -c $metadataCommand $pyprojectPath)
if ($LASTEXITCODE -ne 0 -or $projectMetadata.Count -ne 2) {
    throw "Could not read version and description from '$pyprojectPath'."
}

$projectVersion = $projectMetadata[0].Trim()
$projectDescription = $projectMetadata[1].Trim()
if ($projectVersion -notmatch '^\d+(\.\d+){1,3}$') {
    throw "Project version '$projectVersion' is not valid Windows version metadata."
}

# This metadata is compiled into the executable's version resource, so
# template placeholders would ship to end users.
foreach ($metadataValue in @($projectVersion, $projectDescription)) {
    if ($metadataValue -match 'replace-me') {
        throw "Project metadata '$metadataValue' is still a pyproject.toml placeholder. Set a real project version and description before building."
    }
}

$companyName = "Plain Txt Office"
$productName = "Open PDF"
$copyrightNotice = "Copyright (c) 2026 Plain Txt Office"

$pythonVersion = (& $pythonPath -c "import sys; print(f'{sys.version_info.major}.{sys.version_info.minor}')").Trim()
$pythonRuntimeVersion = (& $pythonPath -c "import sys; print(sys.version.split()[0])").Trim()
$nuitkaVersionOutput = @(& $pythonPath -m nuitka --version)
$nuitkaVersion = $nuitkaVersionOutput[0]
$nuitkaCommercialVersion = $null
if ($nuitkaVersionOutput.Count -gt 1 -and $nuitkaVersionOutput[1].StartsWith("Commercial: ")) {
    $nuitkaCommercialVersion = $nuitkaVersionOutput[1].Substring("Commercial: ".Length)
}

if ($Compiler -eq "mingw64" -and [version]$pythonVersion -ge [version]"3.13") {
    throw "Nuitka cannot use MinGW64 with Python $pythonVersion. Use -Compiler msvc, try -Lto yes, or install Visual Studio's clang component and use -Compiler clang."
}

if ($Compiler -eq "clang" -and -not (Test-ClangCompiler)) {
    throw "Visual Studio clang-cl was not found. Install Visual Studio's clang component, then rerun this script with -Compiler clang."
}

if ($FasterBackendRetry.IsPresent) {
    if (-not $PSBoundParameters.ContainsKey("ShowBackendCommands")) {
        $ShowBackendCommands = $true
    }

    if (-not $PSBoundParameters.ContainsKey("Jobs")) {
        $Jobs = 4
    }

    if (-not $PSBoundParameters.ContainsKey("DisableLowMemory")) {
        $DisableLowMemory = $true
    }
}

& $pythonPath -c "import zstandard" *> $null
if ($LASTEXITCODE -ne 0) {
    throw "Compressed onefile builds require zstandard support from Nuitka[onefile]. Install it into the selected interpreter before building."
}

New-Item -ItemType Directory -Force -Path $resolvedOutputDirectory | Out-Null

$compilerArguments = switch ($Compiler) {
    "msvc" { @("--msvc=$MsvcVersion") }
    "clang" { @("--clang") }
    "mingw64" { @("--mingw64") }
}

$compilerDescription = switch ($Compiler) {
    "msvc" { "MSVC $MsvcVersion" }
    "clang" { "clang-cl from Visual Studio" }
    "mingw64" { "MinGW64" }
}

$nuitkaArguments = @(
    "-m",
    "nuitka",
    "--onefile",
    "--enable-plugin=pyside6",
    "--windows-console-mode=disable",
    "--company-name=$companyName",
    "--product-name=$productName",
    "--file-version=$projectVersion",
    "--product-version=$projectVersion",
    "--file-description=$projectDescription",
    "--copyright=$copyrightNotice",
    "--jobs=$Jobs",
    "--lto=$Lto",
    "--output-filename=$OutputFilename",
    "--output-dir=$resolvedOutputDirectory",
    "--assume-yes-for-downloads",
    "--report=$buildReportPath",
    "src/main.py"
)

$nuitkaArguments += $compilerArguments

if (-not $DisableLowMemory.IsPresent) {
    $nuitkaArguments += "--low-memory"
}

if (Test-Path $iconPath) {
    $nuitkaArguments += "--windows-icon-from-ico=$iconPath"
}

if (Test-Path $assetsDirectory) {
    $nuitkaArguments += "--include-data-dir=$assetsDirectory=assets"
}

# The bundled marker is what makes this build portable: path_handler keeps
# settings, logs, and caches beside the executable when it is present.
if (-not (Test-Path $portableMarkerPath)) {
    throw "Portable marker '$portableMarkerPath' is missing. The onefile build is the portable artifact and cannot be produced without it."
}

$nuitkaArguments += "--include-data-files=$portableMarkerPath=portable.marker"

if ($ShowBackendCommands.IsPresent) {
    $nuitkaArguments += "--show-scons"
}

Write-Host "Building onefile Open PDF executable"
if ($nuitkaCommercialVersion) {
    Write-Host "Nuitka: $nuitkaVersion (Commercial $nuitkaCommercialVersion)"
}
else {
    Write-Host "Nuitka: $nuitkaVersion"
}
Write-Host "Python runtime: $pythonRuntimeVersion"
Write-Host "Python interpreter: $pythonPath"
Write-Host "Output executable: $resolvedOutputExecutable"
Write-Host "C compiler: $compilerDescription"
Write-Host "Stop running output before build: $(-not $NoStopRunningOutput.IsPresent -and $StopRunningOutput.IsPresent)"
Write-Host "Build log: $buildLogPath"

$runningOutputProcesses = Get-ProcessesByExactPath -ExecutablePath $resolvedOutputExecutable
if ($runningOutputProcesses.Count -gt 0) {
    if ($StopRunningOutput.IsPresent -and -not $NoStopRunningOutput.IsPresent) {
        Stop-ProcessesByExactPath -ExecutablePath $resolvedOutputExecutable | Out-Null
        $runningOutputProcesses = Get-ProcessesByExactPath -ExecutablePath $resolvedOutputExecutable
    }
}

if ($runningOutputProcesses.Count -gt 0) {
    $runningProcessSummary = ($runningOutputProcesses | ForEach-Object {
            "PID $($_.Id) ($($_.ProcessName))"
        }) -join ", "
    throw (
        "Cannot rebuild '$resolvedOutputExecutable' because it is currently " +
        "running: $runningProcessSummary. Close the built app and rerun " +
        "this script. The script stops that exact output executable by " +
        "default unless -NoStopRunningOutput is set."
    )
}

$buildStartedAt = Get-Date
Write-Host "Build started: $(Format-BuildTimestamp -Timestamp $buildStartedAt)"

Push-Location $repoRoot
try {
    try {
        $buildExitCode = Invoke-LoggedBuildWithProgress `
            -ExecutablePath $pythonPath `
            -ArgumentList $nuitkaArguments `
            -WorkingDirectory $repoRoot `
            -LogPath $buildLogPath `
            -Activity "Building onefile Open PDF"
        if ($buildExitCode -ne 0) {
            throw "Nuitka onefile build failed with exit code $buildExitCode. See '$buildLogPath'."
        }

        $buildCompletedAt = Get-Date
        $buildDuration = New-TimeSpan -Start $buildStartedAt -End $buildCompletedAt
        Write-Host (
            "Onefile build completed successfully at " +
            "$(Format-BuildTimestamp -Timestamp $buildCompletedAt) " +
            "(duration $($buildDuration.ToString('hh\:mm\:ss')))."
        )
    }
    catch {
        $buildFailedAt = Get-Date
        $buildDuration = New-TimeSpan -Start $buildStartedAt -End $buildFailedAt
        Write-Host (
            "Onefile build failed at " +
            "$(Format-BuildTimestamp -Timestamp $buildFailedAt) " +
            "(duration $($buildDuration.ToString('hh\:mm\:ss')))."
        )
        throw
    }
}
finally {
    Pop-Location
}
