###################
 Nuitka Commercial
###################

*********
 Scripts
*********

This repository keeps local packaging entrypoints here:

- ``standalone.ps1`` for standalone builds
- ``onefile.ps1`` for onefile builds

From the repository root, invoke them like this:

.. code:: powershell

   powershell -ExecutionPolicy Bypass -File .\dev-docs\packaging\nuitka\standalone.ps1
   powershell -ExecutionPolicy Bypass -File .\dev-docs\packaging\nuitka\onefile.ps1

Both scripts default to the repository ``.venv`` interpreter. Override
``-PythonExecutable`` if a different interpreter should run Nuitka.
Both scripts default to Visual Studio's ``clang-cl`` frontend because
MSVC can exhaust its compiler heap on PyMuPDF's generated binding module.
The standalone script also defaults to ``--lto=no``. The onefile script
enables the faster backend retry preset and stops the existing
``build/onefile/Open PDF.exe`` process before rebuilding. Use
``-Compiler msvc`` to force MSVC, or ``-NoStopRunningOutput`` to require
the existing onefile output executable to be closed manually.
``-Compiler mingw64`` is available for older Python versions, but Nuitka
rejects it on Python 3.13 and newer.

If you need to see which generated C file the backend compiler is
currently working on, add ``-ShowBackendCommands``. The onefile script
already enables this through its default faster backend retry preset.
The scripts map that switch to Nuitka's ``--show-scons`` output so the
terminal shows the backend compile commands.

The standalone script forces ``--low-memory`` and ``--jobs=1`` by
default because PyMuPDF-heavy builds can otherwise hit compiler heap
limits during code generation. The onefile script defaults to
``-FasterBackendRetry``, which uses ``-Jobs 4`` and disables
``--low-memory`` unless you override those knobs explicitly. If a
``--lto=no`` MSVC build fails with an MSVC heap error, ``-Lto yes`` is
available as an explicit diagnostic retry.
They now also expose ``-Jobs`` and ``-DisableLowMemory`` as opt-in
escape hatches when a machine has enough RAM and you want shorter,
less idle-looking backend compiler phases.
For convenience, both scripts also expose ``-FasterBackendRetry``,
which defaults to ``-ShowBackendCommands -Jobs 4 -DisableLowMemory``
unless you override one of those knobs explicitly on the same command.
The onefile script enables this preset by default.
They also avoid following ``pandas`` because PyMuPDF's table helper has
an optional ``to_pandas()`` path that this viewer does not use.

For onefile builds, the default command already uses clang, stops the
running output executable, and enables the faster backend retry preset:

.. code:: powershell

   powershell -ExecutionPolicy Bypass -File .\dev-docs\packaging\nuitka\onefile.ps1

Passing ``-StopRunningOutput`` is still accepted, but no longer needed:

.. code:: powershell

   powershell -ExecutionPolicy Bypass -File .\dev-docs\packaging\nuitka\onefile.ps1 -StopRunningOutput

To force the older MSVC shape for onefile builds, override the compiler
and disable the onefile faster preset explicitly:

.. code:: powershell

   powershell -ExecutionPolicy Bypass -File .\dev-docs\packaging\nuitka\onefile.ps1 -Compiler msvc -FasterBackendRetry:$false -Jobs 1 -DisableLowMemory:$false -ShowBackendCommands:$false

For standalone builds, the default command already uses clang. To force
the older MSVC compiler explicitly:

.. code:: powershell

   powershell -ExecutionPolicy Bypass -File .\dev-docs\packaging\nuitka\standalone.ps1 -Compiler msvc

The clang builds require Visual Studio's ``clang-cl`` component. The
scripts check for it before starting Nuitka so a missing component fails
quickly.

If the selected interpreter is Python 3.14 or newer, the scripts warn
that Nuitka still treats that version as experimental and that a 3.13
build interpreter may be more reliable for PyMuPDF packaging.

**********
 Overview
**********

This document is the guide to Nuitka for commercial usage. Under normal
circumstances, Nuitka Commercial will be based stable Nuitka release
(``main`` branch). But there is also a ``staging`` branch that is based
on version of ``develop`` or even ``factory`` depending on when these
appear to be relatively stable. This branch of course bears a higher
risk of regressions.

For repository packaging automation, keep Nuitka packaging scripts in
this directory as PowerShell files. Maintain one script for standalone
builds and one script for onefile builds. Prefer names such as
``standalone.ps1`` and ``onefile.ps1``.

**************
 Installation
**************

Nuitka commercial is now a full copy of Nuitka with the commercial
parts, under restrictive license (must not share with others outside
your team) included.

It is ``pip`` installable from github checkout, and you if you need
that, with GitHub access tokens, but also with your account ssh key
(which is the recommended way if it works for you) and supposed to work
just the same as Nuitka out of the box, with you having to enable
plugins to see differences come to effect.

For creating access tokens for you account check out this page from
GitHub while logged in: https://github.com/settings/tokens and use
"Classic" and click repo, that will be enough.

With an access token, you can clone the repo like this, with your ssh
key, you do not need the token.

.. code:: bash

   git clone https://ghp_ESGksOGvChsfu06PuHOcZXXXX@github.com/Nuitka/Nuitka-commercial.git

For pip you can use this, pipenv, poetry, etc should be able to use the
same URLs no problem, the last bit refers to the branch name. This
should be ``main`` for stable version, but you can also use ``staging``
to get a version that matches the current development version of Nuitka.

Same as above, with an ssh key that is linked to your account, you do
not need the access token to do this:

.. code:: bash

   python -m pip install -U --force-reinstall https://ghp_ESGksOGvChsfu06PuHOcZXXXX@github.com/Nuitka/Nuitka-commercial/archive/main.zip

If you prefer ssh key access, which avoids the whole token issue, use
this which uses git.

.. code:: bash

   python -m pip install -U --force-reinstall git+ssh://git@github.com/Nuitka/Nuitka-commercial/@main#egg=Nuitka

.. note::

   To avoid regressions for commercial users, the stable version may
   occasionally lag behind the public stable version, so after a ``.0``
   release, the update of Nuitka-commercial may get delayed until no
   regressions are known.

****************************
 Deployment Recommendations
****************************

Windows Virus Scanners
======================

Following these pieces of advice, we have successfully deployed to
massive amounts of installations:

-  Change the Windows compiler from MinGW64 to MSVC.

   This is because MinGW64 compiled programs are for unholy reasons more
   prone to be detected as malware. Maybe most malware coders use
   MinGW64 on Windows, and that's a pity, because MinGW64 is known to
   produce faster binaries with Nuitka.

   New research has revealed that MSVC includes 64 bytes into created
   programs that describe your development environment and the source
   code uses. This is called PE file rich headers. See `this link
   <https://www.virusbulletin.com/virusbulletin/2020/01/vb2019-paper-rich-headers-leveraging-mysterious-artifact-pe-format>`__
   if you are interested in details.

   The best way to achieve not using MinGW64, is using ``--msvc=latest``
   which will enforce MSVC usage, or ``--msvc=14.3`` (MSVC 2022) to pick
   a specific one.

   For code created with MinGW64, the MSVC run time is linked in and
   every call of things as simple as ``strcmp`` get traced, which is
   very terrible for protection, since it exposes every string to a run
   time tracing tool.

-  Backup and restore your build environment

   Due to above tracking of your environment, MSVC will allow to detect
   a build of your program in another environment. That is a potentially
   cause for suspicion and may lead to your program as being flagged. If
   at all possible, do not change it and benefit from the trust your
   previous deliveries gained you.

-  Provide consistent and correct Windows version information.

   Use all of Nuitka's version information, and make sure of
   monotonically increase only. Wrong file and build numbers will lower
   the score of your binary for sure.

   Advanced virus checkers track versions of binaries seen in the wild,
   and will consider the information as well. Wrong company name from a
   build environment may be considered against you, so avoid creating
   files with test names, or services with test names to upload them.

-  Sign your executables with `microsoft-authenticode
   <https://www.globalsign.com/de-de/code-signing/microsoft-authenticode>`__

   That is known to be almost required to not get flagged as malware, to
   a point where you should as a commercial user never consider to not
   have it. Naturally the signature will indicate that the origin is
   traceable and your binary is more likely to be accepted. Only use EV
   certificates that are trusted by Microsoft, see `this link
   <https://docs.microsoft.com/en-us/windows-hardware/drivers/dashboard/get-a-code-signing-certificate>`__
   for a list of trusted resellers.

   There are **two** basic types: OV and EV. OV types might still
   trigger MS ``harmful software`` screen; EV (Extended Validation)
   should not. Make sure to get that kind of certificate or your success
   can be limited.

   If you want to use self signed certificates, create them like this,
   note however, that while still somewhat beneficial on the long run,
   it will take a bunch of releases until AV vendors pick them up as
   more trusted, some bigger institutions get away with them. Make sure
   to update the email of course.

   .. code:: powershell

      $cert = New-SelfSignedCertificate -certstorelocation cert:\localmachine\my -type CodeSigning -dnsname your@email.net
      $pwd = ConvertTo-SecureString -String password -Force -AsPlainText
      $path = 'cert:\localMachine\my\' + $cert.thumbprint
      Export-PfxCertificate -cert $path -FilePath my-signing.pfx -Password $pwd

-  Do the signing with the code signing plugin of Nuitka commercial,
   using ``--enable-plugin=signing`` and
   ``--windows-certificate-filename`` options as that plugin will sign
   your executes better than just signing the resulting onefile binary.
   You can select the certificate if registered in the system via SHA
   with ``--windows-certificate-sha1`` or by name with
   ``--windows-certificate-name``.

-  Submit your executables to `virustotal
   <https://www.virustotal.com>`__ in order to make sure that no AV
   engines detect your binaries as fraudulent. If so, get in touch with
   the AV engine editor before publishing your executable. This will
   prevent other AV engine databases to get fed later.

-  Avoid the doc strings of stdlib. These will contain a bunch of URLs,
   all of which are a concern for the analysis of your binary. It
   appears that the majority of these URLs are high reputation, but some
   are now, e.g. and this is causing some engines to consider them as
   risks. One example is ``mahler:8092/site-updates.py`` for which there
   is no way that will change.

   These doc strings will also be covered by the data hiding plugin. So
   far no adverse effect has been observed, i.e. programs are not
   punished for using that, but it's probably still a good idea to avoid
   the data at runtime.

-  Do not manually rename the created files after the fact. The option
   ``--output-filename`` of Nuitka should be used to give it the final
   name, or you should rename the file compiled to match what you want
   to get out of the compilation. The version information embedded by
   Nuitka into the binary allows to detect this renaming, as it counts
   towards being malicious to provide a file renamed. And when that is
   not happening, it's considered a plus.

Isolation
=========

As of 1.7 there is a new flag, ``--python-flag=isolated`` that will
prevent outside code from being loaded.

.. note::

   If you have to do a plugin loading system, beware, this opens up your
   program code code injection. Currently we have no sandbox or anything
   for that, so this kind of code can poke around.

.. note::

   Use this with standalone mode where it is most effective, but for
   accelerated mode, it makes no sense, you will not be able to load
   modules not included.

Should you require being able to load some sort of user plugins to your
code, try to only briefly add to ``sys.path`` which is empty with that
option, do the one import from disk, and then remove it again.

Size and Data Reduction
=======================

In your code, you have potentially doc strings. These are kept by
default. Use ``--python-flag=no_docstrings`` to remove these before
deployment. This is not the default, because in your code you might use
these, and Nuitka cannot know that, it is however very unlikely to be
the case. There is no equivalent in standard Python, the closes is
``-OO`` which implies no assertions too though.

If you make certain that your program runs with ``python -O`` you can
also apply the ``--python-flag=no_asserts`` option.

.. note::

   It is very easy to overlook the impact of assertions not being
   executed, it is your responsibility of course to make sure your
   program works with these modes before applying them in Nuitka and
   then to discover they are not working.

For annotations, Nuitka doesn't currently offer anything to remove them.
The best approach is to use ``3to2 -f annotations`` on your code. The
equivalent will appear in a commercial plugin later, but what this does
is to remove what can be recognized on the language level as an
annotation.

.. note::

   There is now an option ``--python-flag=no_annotations``, but
   sometimes removing annotations can lead to code that will fail to
   execute. It is therefore still recommended to perform this with the
   above workaround if that happens to you. One example is Telethon,
   where a function that does some comparison of signatures and
   documentation fails. It needs to be disabled.

Also, if you are using annotations, consider making them comments, like
this,

.. code:: python

   def aes_encrypt(msg, aes_key):
       # type: (bytes, bytes) -> Tuple[Union[bytes, bytearray, memoryview], bytes, bytes]
       ...

In this case, they won't possibly available at run time, but tools like
Visual Code do pick these up still. To CPython, annotations are largely
comments in code form, and a big issue. Annotations cause a lot of code
to be created by Nuitka that makes no sense.

Data Files in Binary
====================

The commercial plugin ``datafile-inclusion-ng`` is used for embedding
data files. Its features are:

#. Works with module mode or accelerated mode, and of course standalone
   and onefile mode (which is just the same standalone to the Python
   level).

#. You specify the data files through plugins, command line options,
   whatever, and only in second step, you say for the target files,
   which ones should be embedded. This means, you can get it to work
   without embedding anything in step 1, and then make it work without
   that.

#. Two forms of file embedding, one allows compile time optimization of
   the file content, the other loads at run time.

#. Special embedding for Qt files.

Usage, e.g. like this:

.. code:: python

   # nuitka-project: --include-package=package
   # nuitka-project: --embed-data-files-runtime-pattern=*
   # nuitka-project: --include-package-data=package

   # Module mode only,
   # nuitka-project: --module-name-choice=original

Then inside ``package/__init__.py``, e.g. do this:

.. code:: python

   import pkgutil

   # Setting version from a file, is an example use case of this, but not limited
   # to that of course.
   __version__ = pkgutil.get_data(__package__, "DATA_FILE.txt").decode("ascii").strip()

   print(__version__)

The test case ``tests/programs/pkgutil_usage/PkgUtilUsageMain.py``
illustrates the use of this.

However, many more features are supported. Checkout
``tests/commercial/DataInclusionTest.py`` which exercises uses of
``open``, ``pkg_resources``, ``importlib.resources``, Qt resources,
Jinja2 templates, and likely more, the aim is for Nuitka to be
completely working. This is of course a moving goal and you can report
if you find a method of file access from Python code, that is not
working.

.. note::

   For best protection, ``run-time`` should be used. For compile time
   inclusion with weaker protection (like any other constant value of a
   module), there is the option
   ``--embed-data-files-compile-time-pattern=*``.

.. note::

   Not all files can be included. Specially tk-inter provided Tcl files
   cannot be embedded by Nuitka commercial and then be found at runtime
   by the Tcl interpreter. There are other cases like that when C
   extension code opens a file without using the Python ``open`` or
   other methods of Python, then Nuitka commercial cannot do it.

PySide2 Usage
=============

Preface
-------

When using Nuitka and Qt, historically PyQt5 was the best supported
toolkit as Riverbank has merged some patches, where PySide originally
did not. This situation has totally reversed. For PyQt5 there are known
bugs without any patches, for PySide2 as provided by Nuitka, and PySide
6.3 or higher, there are usually no known issues at all.

Nuitka and Qt company are working together, and on the roadmap there
will be more improvements related to Nuitka all the time.

If you use Qt5, it is strongly recommended to migrate to PySide2 as
provided from Nuitka, and for Qt6, it is recommended to only consider
PySide6 with it being provided under the more liberal license, yet still
with commercial support available and with Nuitka support.

How to use it
-------------

To use Nuitka with PySide2 enabled, there are pre-compiled wheels
available for Windows 32/64 bits, Linux x86_64, macOS 10.14 or higher.
These wheels and the patched source code can be downloaded from:
https://github.com/Nuitka/Nuitka-commercial/releases/tag/pyside2_5.15.2_wheels_v1

The Qt company's open source license that is relevant is the LGPL. It
mandates that any modification is made available to the recipients. Also
Qt company is asking to state the Qt usage. Therefore I recommend the
following to be added to your software documentation if you use the
patched version of PySide2, for PySide6 this doesn't apply in the same
way as there is no modification from our side that is not in the
original package.

.. note::

   This software uses Qt and one of its components (PySide2) in modified
   form, the modified source code of PySide2 is made available at
   https://nuitka.net/releases/PySide-5.15.2-with-Nuitka.tar.gz in case
   you want it.

.. note::

   disclaimer

   I am not a lawyer. This is not legal advice, it's my best
   understanding of what is required for compliance with the license
   used.

The Nuitka plugin recognizes those wheels from a variable
``_nuitka_patch_level`` in ``PySide2``. You can also check its existence
to make sure it's present. Absent that, Nuitka will give warnings that
point out the use of workarounds that are incomplete and harmful to the
performance.

Support for Python3.10 or higher
--------------------------------

The PySide2 wheels are built against Python3.9, and refuse to install on
3.10 or higher. Initially I was not interested in supporting 3.10 or
higher with rebuilds, because esp. on Windows, it makes very little
sense to not use PySide6 instead. People migrating to newer Python, and
stay on the old toolkit are rare.

However, there are people who appreciate the more minimal effort to go
from PyQt5 to PySide2 only. And therefore, the following approach was
tested, and confirmed to work.

Install the PySide2 wheels to a 3.9 virtualenv. There needs to be
nothing else in there yet, then go to ``Lib/site-packages`` of that
virtualenv, and copy ``shiboken2*`` and ``PySide2*`` files to the target
Python installation, which can be Python3.10 or higher. It will then
even be recognized as properly installed by metadata tools.

Sorry for needing a hack here. Like I said, using 3.10 and PySide6 is
what is recommended from here on, but this can be a useful intermediate
or final step, depending on your software lifecycle phase.

Container Build
===============

Rationale
---------

For Linux standalone it is pretty difficult to build a binary that works
on other Linux versions. This is mainly because on Linux, much software
is built specifically targeted to concrete DLLs. Things like glibc used,
are then encoded into the binary built, and it will not run with an
older glibc, just to give one example.

The solution is to build on the oldest OS that you want to see
supported. Picking that and setting it up can be tedious, so can be
login, and keeping it secure, as it's something you put your source code
on.

To aid that, Nuitka has container builds, that you can use. These
containers use CentOS 7 which is based on Fedora 19. Software built here
with Nuitka will run on practically everything, e.g. Ubuntu 2204 und
Fedora 34, but also between. On the other hand, it can be used on
latests Ubuntu and Fedora, the OS you likely use for development.

The container build uses Podman, as it's superior to Docker, at least
that's what they say, and very importantly can run without using root or
any daemon needed, so it is low key in setup.

The C tool chain used there is not the original one, but an improved one
from EPEL and SCL, provided and commonly used by professionals. Their C
compilers are relatively modern (gcc 9 vs gcc 4) and produce way better
code.

Also, the Python will be compiled with the options that will allow
static linking. In the container, Python is built from source with
options to designed to make it run well for Nuitka.

Example Usage
-------------

Currently, the way you use it is this

.. code:: bash

   # Ubuntu 2104
   apt-get install podman
   # New Debian/Ubuntu may also need this to run without root.
   apt-get install uidmap slirp4netns

   # Fedora 34
   yum install podman

   # The Python version defaults to what you use to run it, should match
   # best what you are using, but can also be provided --python-version=3.9.6
   # if you want something specific.
   python -m nuitka.tools.commercial.container_build YourSourceDirectory YourMainprogram.py build \
   --wheels=PySide2-wheels

This will then mount your source code and the build directory and build
inside the container and produce results in the build directory. Using
the PySide2 wheels is of course optional. It makes assumptions about the
requirements, you install them via pip. There is ``--requirements`` to
override the default to use ``pip install -U -r requirements.txt``
inside the container. Use e.g. ``--requirements="-r
mycustomefilename.txt"``.

Podman Knowledge
----------------

These commands are useful with podman images, and roughly the only ones
you need, if any.

.. code:: bash

   # Listing images, ours our named e.g. localhost/nuitka-build-3.9.6-<hash_value> where
   # the later is the hash of the Container file Nuitka uses. You should ignore the
   # "localhost" part in other commands
   podman images

   # Removing an image
   podman rmi -f nuitka-build-3.9.6-<hash_value>

   # Removing everything currently unused
   podman system prune -a

*************************
 Runtime Recommendations
*************************

When you deploy a module, it exposes the interface at run time. An
attacker can see the contents of the module directory easily. It is
recommended to make you module like this:

.. code:: python

   import types

   __all__ = "f",

   def __dir__():
      return __all__

   class MyModuleDict(types.ModuleType):
      def __init__(self, name):
         types.ModuleType.__init__(self, name)

      def __getattr__(self, name):
         try:
            if name in __all__:
                  return globals()[name]

            if name in ("__path__", "__file__", "__doc__"):
                  return globals()[name]

            raise AttributeError(name)
         except KeyError:
            raise AttributeError(name)
         else:
            raise AttributeError(name)

      def __dir__():
         return __all__

   sys.modules[__name__] = VFModule(__name__)

   import submodule # whatever you use

   def f():
      pass

   def _secret():
      pass

With this in module, it becomes more difficult to see what you are
exposing with interactive Python prompt. For accelerated mode and
standalone mode, this is not needed as much.

*********
 Plugins
*********

General Instructions
====================

The plugins from the ``nuitka/plugins/commercial`` folder need to be
manually copied to the corresponding folder in your Nuitka installation.
In the future we might add setup that imports this more automatically.
Make sure that the versions match. Right now, Nuitka 0.6.10.2 or higher
is needed.

Windows Services
================

In your code, you do not do anything special. If you have previously
used something like ``win32service``, remove this. Nuitka handles all
interaction with the system for you.

.. code:: python

   try:
       while True:
           # Do your service work here as you would normally do it,
           # of course trying to not busy loop.
           ...
           time.sleep(1)

   except KeyboardInterrupt:
       # Service is being stopped, e.g. shutdown, manual
       # you have a little time for cleanups until getting hard killed.
       ...

The plugin enables the creation of Windows Service executables. These
will have an ``install`` parameter, which when given will add the
registry information, but of course you can also add them manually like
this.

.. code:: bash

   sc.exe \\myserver create NewService binpath= c:\some_path\NewServ.exe

.. note::

   The created binary has a hidden parameter ``install`` that will
   delete the service and create it automatically with the binary path
   set correctly, and therefore it will be relatively easy. Extra
   arguments passed after install become arguments passed to the service
   at run time.

   Every other configuration of the service could be added, but it would
   take work and somebody to fund this. For now, this is mainly intended
   for simple use cases and internal automatic testing of the plugin.

.. note::

   There are options to force the output of the service to standard
   output and standard error into specified files. For debugging, you
   can specify e.g. ``--force-stdout-spec='{PROGRAM_BASE}.out.txt'`` and
   ``--force-stderr-spec='{PROGRAM_BASE}.err.txt'``. Refer to the User
   Manual of Nuitka for allowed special monikers. Of course, absolute
   paths are allowed too.

The plugin is enabled with ``--enable-plugin=windows-service`` and has a
required parameter ``--windows-service-name`` which will be used as the
service name.

Combine this with ``--windows-company-name`` and ideally all related
options to provide a proper version resource, increasing the trust in
the binary further.

The created binary does not run directly anymore, but only as a service.
It has a special argument handling for ``install`` as the first
argument, in which case, even if not running as a service, it will
delete the existing service and replace it with itself, of course that
will require the privilege to do so. Any extra arguments passed to
install will be passed to the service binary, e.g.

.. code:: bash

   my-service.exe install some_arg another_arg

This will lead to service run time ``sys.argv`` containing
[``some_arg``, ``another_arg``] as well as naturally the actual path of
the service binary.

The best way to deploy a service is to use ``--onefile`` and then also
``--onefile-tempdir-spec={CACHE_DIR}/{COMPANY}/{PRODUCT}/{VERSION}`` in
which it installs the service files to your local app folder and passes
on the ``install`` argument it got to the service file put there. This
makes it use the same location. That is good for Windows Firewall to not
see changing file names for the executable.

If you are going to use this, consider using ``--windows-uac-admin``
which will make the onefile binary elevate privilege so it can do the
service installation, so works directly for a user.

The use of temporary files is not recommended and being warned against,
it will make the service startup slower, do IO, and potentially
accumulate undeleted files e.g. in case of power failure.

..code:: bash

   reg query "HKLM\System\CurrentControlSet\Services\Nuitka Test
   Service" /v "ImagePath"

Gives outputs:

.. code::

   HKEY_LOCAL_MACHINE\System\CurrentControlSet\Services\Nuitka Test Service
       ImagePath    REG_EXPAND_SZ    C:\Users\kayha\repos\Nuitka\WindowsServiceTest.exe
       ImagePath    REG_EXPAND_SZ    C:\Users\kayha\AppData\Local\Nuitka Test Company\Nuitka Test Product\1.0.0.0\WindowsServiceTest.exe

The first one is for onefile with temporary spec, and the second one is
the cached one.

One advantage (and actually disadvantage) of temporary onefile spec
would be that updating does not require to change the service
installation again, since you could just replace the onefile binary.

So while it's not good, to use onefile with temporary mode, e.g. because
you do not want the unpacked files to exist when not running, it is
working, but it has to go through the unpacking each time, which is bad
for startup performance.

.. note::

   The current ``install`` does mode not allow all the features. Get in
   touch with me if you are willing to fund a bit of extra time to add
   more ones, so you can save yourself creating a Windows installer
   integration with ``--standalone`` mode deployment.

Data Hiding
===========

In your code, you do not do anything special, you just enable the plugin
with ``--enable-plugin=data-hiding`` and this has two effects. On Linux
and macOS the constants blob of Nuitka becomes writable at run time, and
is decoded during program startup. In the file, all constant data will
be unrecognizable.

As a demonstration, lets use ``tests/basics/Asserts.py`` from the
official Nuitka tests, it tests through some variants of exceptions.
Counting the occurrences of ``Assert`` we get 10 times as of writing
this. With a mere

.. code:: bash

   grep -e Assert tests/basics/Asserts.py

Now if we check the compiled file (without plugin, doing this on Linux
for available tools, but Windows is similar), we get this:

.. code:: bash

   strings Asserts.bin | grep Assert

And the following output (changed order):

.. code::

   atestAssert1
   atestAssert2
   atestAssert3
   uAssertion with tuple argument.
   uAssertion with plain argument.
   PyExc_AssertionError

These are from the constants blob. The first ones are function names,
and the later ones are strings printed. The next one is a CPython ABI
function that Nuitka looks up in ``libpythonX.Y`` and that's technically
required to be there.

Now with the plugin enabled, the output becomes empty. That is in a
nutshell, what the plugin is supposed to do.

I will try and give a description of how the plugin is a best effort to
hide your data and make it close to impossible to decipher it offline.
At run time, values must be decoded, and the decoder and key, must be
included, but there are several things, the plugin does to fend offline
analysis off.

#. The key is in part in the code that the plugin adds to your binary
   and that will change with the data provided. This is designed to
   require that an attacker would have to disassemble the code, and know
   where to look for to get ahold of an part of the decoding key.

#. From the adler32 value, a random seed is generated. This is used to
   shuffle a translation of your data from one byte value to other value
   bytes with no predictable values.

#. As it goes, the previous byte value is taken into account, as well as
   the position, to produce noise that should make stochastic analysis
   much less fruitful.

#. To fend of known plaintext approached, the data is seeding with
   pseudo random values, namely the MD5 sum of your data. At the time it
   arrives at potentially knowable data, e.g. the names of standard
   library modules, the algorithm will have shifted and XOR-ed the data
   so much, that this is impossible to tell what data is there.

#. Then the MD5 sum is also used to modify with another rotation per
   modulo 8 to further scramble this, and this is hidden in the code
   generated.

With this scrambling, it's clear it would take a high skill attacker to
derive any information for the binary in offline form, such that the
goal is achieved, and it takes an attack on the program while running.

.. note::

   The plugin does not protect information that is output or in an
   unhandled exception traceback. Until Dejong Stacks are available, it
   is advised to make certain to catch all exceptions before program
   exit, so that they are never printed.

Traceback Encryption
====================

The traceback encryption is enabled with
``--enable-plugin=traceback-encryption`` and in the current form is
still incomplete (with regards to configuration), but very usable. You
have the option to encrypt the stdout and stderr of your program with
the options ``--encrypt-stderr`` and ``--encrypt-stdout``.

.. note::

   For capturing these into files, these options ``--force-stdout-spec``
   and ``--force-stderr-spec`` should be used.

The output is done in base64 such that it should be robust to transfer
via email, however the decrypting parser is fragile and will only work
if the file was not messed with. Also putting stdout and stderr in the
same program will occasionally make it crash. It is a future goal to
ensure that streams of output can mix freely and still be decoded, but
that will be happening when configuration is implemented.

The binary ``nuitka-decrypt`` will need the key generated or used during
the compilation. You should set this key file aside, otherwise you will
not be able to decrypt the output.

For the time being, the encryption has open items, esp. related to
logging exception values. While ``sys.exc_info()`` will contain
encrypted information and change the exception type, the direct catching
does not. Future work will attempt to make this robust in as so far it's
doable. It may never be fully working and require programmer care.

.. note::

   Expect that future releases will become unable to decrypt the output
   of this version. This is mainly for evaluation, and should not be
   used for binaries that you will support for years to come. The
   concept of configuration is not yet foreseen.

For programmatic evaluation of output, this kind of code can be used,
but the same caveat applies.

.. code:: python

   from nuitka.tools.commercial.decrypt import Dejong
   from nuitka.utils.FileOperations import getFileContents

   config = Dejong.getDefaultConfigWithKey(getFileContents(options.key, "rb"))

   # kind is a classification, e.g. "stdout", "stderr", "plain"
   # exc_info is a traceback information contained.
   for kind, output, exc_info in Dejong.decryptOutput(config, input_file):
      print(output, end="")

.. note::

   Currently the code that does the encryption uses ``pycrytodomex``
   (recommended and default) but can be made to use ``pycryptodome`` as
   well using the ``--encrypt-crypto-package`` package.

Example output:

.. code:: python

   # nuitka-project: --enable-plugin=traceback-encryption
   # nuitka-project: --encrypt-stdout
   # nuitka-project: --encrypt-stderr

   from __future__ import print_function

   import sys

   some_var = "secret"


   def f():
       print("Hello encrypted stdout world", end="")
       print("Lets also do stderr world\n", file=sys.stderr)
       print("we got interrupted")

       x = TypeError(some_var)
       print("Got an exception:", x)

       raise KeyError(2)


   f()

.. code::

   python -m nuitka tests/commercial/TracebackEncryptionTest.py

   # Run it, could also have --force-stdout-spec --force-stderr-spec outputs used
   ./TracebackEncryptionTest.bin >out.txt 2>&1

   cat out.txt
   Z-OeD9p76EpDzsVvSrLTwMM3q+VYLbvtEi9hJoeP8WgnPEnIEaQ8uxd2+wweKa2ljjBOPJkJpFG79io2utHh4tA4RqR95s4SDuDg==-A
   Z-D7a/0aXLl6YB1OrSA6ojlRg0zLcAqrhyo7uYLounqzgxmF+BMhwqqbgGLi9bSOg4-A
   X-gGUh2JbMEewix6kRRcxNJUR0OFLDYOZ8vnfwk2odAlwRHUhiHH/QL/8QGIoodhW3RpoKsjFNAd8IgusbWL2aRgyn0J8mbeVq/TNY-Y
   X-KUm3etPVNdjaIA+VnJuNIOs8T7owi92TeQ3tYb2RzFljgsu2HJd1oiVS6dWNGEY=-Y
   X-NDtWFWpk5X1qva9SJwtn38g3L388w+WdCyaFRHZRG4Y4sfOX8JshYNs2o0WnxPctctHO991iPsYiHEdTu8EM4+4=-Y
   X-61h/DnsybZYxq1/MvLiQwXojrbIRaL97pgm45mQe/YPcBW0j9zYRIKUA49Q41N2T-Y
   X-fzO3OVAx+ugM6DnDXhlI/8KU4/lFbym4N9DzBy4xoxv+hNshIWw+y4pTlD9QAVGlUnwp+cR9Ry+k8fG/4vkOmA==-Y
   X-QXJO5o0V+i9XKGVYynMkleP3WCgrmaYImVHdR9JDPIL2GPgf6ezqaiYJy8fj5+Y0-Y
   X-ZRfYUYBbFKRbHZyCTlSnCYBzcWAcCkmeyn0XRd1zXjxcUzKtLtz5+uXgByWoLCWnhLccbSk=-Y
   X-ps7BFw5jxIpxsXRgvVb1BuxuKXt8a1PoppbgaZDPNRf/7z2ZD07AWVa/5Yv+tvqo-Y
   Z-3BG9tSlX/4veoI6PQTES5r4R0v3Zw8gkMlbd27JniqKiC1i7jpvk0aJ7+kuqErVT4eZELLtCarlYPkwpOfKNHn0RbkouvUoA0U3TW42/VIpR4CkXkhXdvQy1g2M6JXSA4qoV3InY0kqUgQlZhZxDk+LoOqqCTjYz4gjJezRs4tKIjXKL6Jff8ennY1YZshEVXtb2bZ9EEAtOZSAhhejITJYTvuMowErKeOw6NPcjPk42u2wtzYKhcRhuzUbCRd3j8Z+Zfbl/Ms7DQuytxoY3oTBbQhiwE0LDzqsksi19EOg7IuRvQ1dFoj6Jmw+VVwOkTZBO35HJ8BTdnVWBnfiBEJ5Z2tS+nnzgT0uOHpUDdgCw8VNgnG5htdiREqEL6zDPfr+ZQ3JkIDtnc+VDytYki3ZeBGQBCFkJHWgl7rcbcl/HdGIaBTYOhjZiU+V/iCZN6HPOHrPVdMPNoiHXJub1d/Ad3xWLtgXwExpqx4mzw1HET8MpeOowhq7m5+piNDGCA6DaM21HZwuxqoqNrEzhKddi+xdQ42v5OCw5Bh7pzG4H4sVDA7gC+MJ3f+7oZIPac+jnLYRABjnud0SYf6LMxL2QRIAUImLUnraqZL19me1lf8X0Scb70GTAGeoZGMind+EMlhJ5eegTjvapdrfifWc1j35nWsk4yC7D33WmWcbzDAn1uJAwT34rM2E7ytoXCB5Kayth//bop2MAyFOlNWJOthpr1q39w8p3YuOuH5stNV+GHdWHw1pYK4yvjWd1/XIEuxK+iczuRBgyFwpwFwr/u6TDWfTrEI36OKExOtS6OnUUwra6kBNYfJZJ/+uPoyA18GY5lSD1DgZzTdVdOhFfG4gRDXxjgR0YwukHOtzv4o9lJIBccESnGYVz+PEvUzMKUEoMHnPBxvfhg6fD1AsmbVezfe1q0nB60ItX3EnCWH+fr6F5CmGnXqangVHuYnrgtsyK8Da+46sOOTUPStWcIXQkjhp4MuPp+JpMXSoLNYLL23uaP7MtHTsgZI8Fs5aPoUVcTv6obGdaB1bA9b/pe93i3GFYbFBHxUe8tGnntBgXkhi1sEj/V5Z2/o8dRuM7Xr5hpPEGBjVbqdXHGqsyoWVnZMMDksjzrzq/fzunIkQwBnGeByqjy8TDK117mz9kT0Wc1dWS0utbZ8Wecx5xWbmrz3prFzr5+1xyJK1zLv1TiilXqU1jgVGQISfeTWttm5OxQWVZY1s+7IRoVJTYFypyIm4epuKM-A

   cat out.txt | python -m nuitka.tools.commercial.decrypt --key=TracebackEncryptionTest.bin.key
   Lets also do stderr world

   Hello encrypted stdout worldwe got interrupted
   Got an exception: secret
   Traceback (most recent call last):
   File "/home/hayen/repos/Nuitka/tests/commercial/TracebackEncryptionTest.py", line 24, in <module>
      f()
   File "/home/hayen/repos/Nuitka/tests/commercial/TracebackEncryptionTest.py", line 21, in f
      raise KeyError(2)
   KeyError: 2
