# Create a fresh ZIP of the project's source from an EXPLICIT ALLOWLIST.
#
# Nothing is included unless it is named below. A new file holding credentials,
# tokens or personal notes therefore cannot be swept into a published archive by
# accident -- which is the failure mode of an exclude-based approach.
#
# The default list is the set GPL-3.0 and AGPL-3.0 call "Corresponding Source":
# the code, plus the metadata and scripts needed to build, install and run it.
# Shipping a binary under either license obliges you to provide that, not just
# the source tree.
#
# Usage:
#   .\zip-src.ps1
#   .\zip-src.ps1 -OutputPath "C:\archives\src.zip"
#   .\zip-src.ps1 -Include 'src','pyproject.toml','LICENSE'
#   .\zip-src.ps1 -AllowMissing        # skip the required-entry check
#
# Per-project overrides live in dev-docs/packaging/zip-src.include -- one path
# per line, '#' starts a comment. When that file exists it REPLACES the
# defaults, so copy the list below before trimming it.
[CmdletBinding()]
param(
    [string]$OutputPath,
    [string[]]$Include,
    [switch]$AllowMissing
)

$ErrorActionPreference = 'Stop'

# --- what goes in ---------------------------------------------------------

$defaultInclude = @(
    'src'
    'tests'
    'scripts'
    'dev-docs/packaging'
    'pyproject.toml'
    'LICENSE'
    'README.md'
)

# Without these the archive does not let a recipient build the project or
# redistribute it lawfully. Override with -AllowMissing.
$requiredEntries = @('pyproject.toml', 'LICENSE')

# Belt and braces on top of the allowlist. Only shapes that are never source
# code are excluded outright -- a fuzzy pattern such as *token* would silently
# drop a legitimate tokenizer module, so suspicious names are reported after
# the build instead of being dropped here.
$excludeArguments = @(
    '-xr!__pycache__'
    '-xr!*.pyc'
    '-xr!*.pyo'
    '-xr!.venv'
    '-xr!.env'
    '-xr!.env.*'
    '-xr!*.pem'
    '-xr!*.pfx'
    '-xr!*.p12'
    '-xr!id_rsa*'
    '-xr!id_ed25519*'
    '-xr!*.log'
    '-xr!.DS_Store'
)

# Reported, not excluded: names worth a second look before publishing.
$suspiciousNamePattern = '(?i)(secret|credential|password|api[_-]?key|access[_-]?key|private[_-]?key|\.key$|\.token$)'

# Reported, not excluded: high-signal credential shapes found inside files.
$contentPatterns = [ordered]@{
    'OpenAI key'        = 'sk-[A-Za-z0-9_\-]{20,}'
    'AWS access key id' = 'AKIA[0-9A-Z]{16}'
    'GitHub token'      = 'gh[pousr]_[A-Za-z0-9]{36}'
    'Slack token'       = 'xox[baprs]-[A-Za-z0-9-]{10,}'
    'Private key block' = '-----BEGIN [A-Z ]*PRIVATE KEY-----'
    'Assigned secret'   = '(?i)(api[_-]?key|secret|password|token)\s*[:=]\s*["''][A-Za-z0-9_\-]{16,}["'']'
}
$scannableExtensions = @(
    '.py', '.ps1', '.psm1', '.toml', '.cfg', '.ini', '.json', '.yaml', '.yml',
    '.md', '.txt', '.bat', '.cmd', '.sh', '.env', '.xml', '.html', '.css', '.js'
)

# --- locate the project root ----------------------------------------------

$repositoryRoot = (Resolve-Path -LiteralPath $PSScriptRoot).Path
while ($repositoryRoot -and
       -not (Test-Path -LiteralPath (Join-Path $repositoryRoot 'pyproject.toml') -PathType Leaf) -and
       -not (Test-Path -LiteralPath (Join-Path $repositoryRoot 'src') -PathType Container)) {
    $parentRoot = Split-Path -Parent $repositoryRoot
    if ($parentRoot -eq $repositoryRoot) {
        $repositoryRoot = $null
    } else {
        $repositoryRoot = $parentRoot
    }
}
if (-not $repositoryRoot) {
    throw 'Could not find a project root containing pyproject.toml or a src folder.'
}

# --- resolve the include list ---------------------------------------------

$separator = [System.IO.Path]::DirectorySeparatorChar
$includeFile = Join-Path $PSScriptRoot 'zip-src.include'
if ($Include -and $Include.Count -gt 0) {
    $includeList = $Include
    $includeSource = '-Include parameter'
} elseif (Test-Path -LiteralPath $includeFile -PathType Leaf) {
    $includeList = @(Get-Content -LiteralPath $includeFile |
        ForEach-Object { $_.Trim() } |
        Where-Object { $_ -and -not $_.StartsWith('#') })
    $includeSource = $includeFile
} else {
    $includeList = $defaultInclude
    $includeSource = 'script defaults'
}
if (-not $includeList -or $includeList.Count -eq 0) {
    throw "Include list resolved to nothing (source: $includeSource)."
}

$present = @()
$absent = @()
foreach ($entry in $includeList) {
    $normalized = $entry.Replace('/', $separator).Replace('\', $separator)
    if (Test-Path -LiteralPath (Join-Path $repositoryRoot $normalized)) {
        $present += $normalized
    } else {
        $absent += $normalized
    }
}
if ($present.Count -eq 0) {
    throw "None of the listed paths exist under $repositoryRoot."
}

$missingRequired = @($requiredEntries |
    Where-Object { -not (Test-Path -LiteralPath (Join-Path $repositoryRoot $_.Replace('/', $separator))) })
if ($missingRequired.Count -gt 0 -and -not $AllowMissing) {
    throw ("Missing required file(s): {0}. A published archive without these cannot be built from or lawfully redistributed. Add them, or pass -AllowMissing if this project is not distributed." -f ($missingRequired -join ', '))
}

# --- resolve the output path ----------------------------------------------

if ([string]::IsNullOrWhiteSpace($OutputPath)) {
    $OutputPath = Join-Path $repositoryRoot 'exports' (
        "src-{0}.zip" -f (Get-Date -Format 'yyyyMMdd-HHmmss-fff')
    )
}
$archivePath = $ExecutionContext.SessionState.Path.GetUnresolvedProviderPathFromPSPath($OutputPath)
if ([System.IO.Path]::GetExtension($archivePath) -ne '.zip') {
    throw 'OutputPath must end in .zip.'
}
foreach ($entry in $present) {
    $entryPath = Join-Path $repositoryRoot $entry
    if ($archivePath.StartsWith($entryPath + $separator,
                                [System.StringComparison]::OrdinalIgnoreCase)) {
        throw "Choose an output path outside the archived content: $entry."
    }
}
if (Test-Path -LiteralPath $archivePath) {
    throw "Archive already exists. Choose a new OutputPath: $archivePath"
}

# --- find 7-Zip -----------------------------------------------------------

$sevenZipCommand = Get-Command '7z' -ErrorAction SilentlyContinue
$sevenZipPath = if ($sevenZipCommand) {
    $sevenZipCommand.Source
} else {
    Join-Path $env:ProgramFiles '7-Zip\7z.exe'
}
if (-not (Test-Path -LiteralPath $sevenZipPath -PathType Leaf)) {
    throw '7-Zip was not found. Install it or add 7z.exe to PATH.'
}

# --- build ----------------------------------------------------------------

[System.IO.Directory]::CreateDirectory((Split-Path -Parent $archivePath)) | Out-Null
Push-Location -LiteralPath $repositoryRoot
try {
    $arguments = @('a', '-tzip', $archivePath) + $present + $excludeArguments
    & $sevenZipPath @arguments | Out-Null
    if ($LASTEXITCODE -ne 0) {
        throw "7-Zip failed with exit code $LASTEXITCODE."
    }
} finally {
    Pop-Location
}

# --- report what actually shipped -----------------------------------------

Add-Type -AssemblyName System.IO.Compression.FileSystem
$archive = [System.IO.Compression.ZipFile]::OpenRead($archivePath)
try {
    $entries = @($archive.Entries | Where-Object { $_.Name })
    $names = @($entries | ForEach-Object { $_.FullName })

    $flaggedNames = @($names | Where-Object { $_ -match $suspiciousNamePattern })

    $flaggedContent = @()
    foreach ($entry in $entries) {
        $extension = [System.IO.Path]::GetExtension($entry.Name)
        if ($scannableExtensions -notcontains $extension) { continue }
        if ($entry.Length -gt 1MB) { continue }
        $reader = New-Object System.IO.StreamReader($entry.Open())
        try {
            $text = $reader.ReadToEnd()
        } finally {
            $reader.Dispose()
        }
        foreach ($label in $contentPatterns.Keys) {
            if ($text -match $contentPatterns[$label]) {
                $flaggedContent += [pscustomobject]@{ File = $entry.FullName; Kind = $label }
            }
        }
    }
} finally {
    $archive.Dispose()
}

Write-Output "Created: $archivePath"
Write-Output "Include list from: $includeSource"
Write-Output "Files archived: $($names.Count)"
if ($absent.Count -gt 0) {
    Write-Output "Listed but not present (skipped): $($absent -join ', ')"
}
Write-Output ''
Write-Output 'Top-level contents:'
$names |
    ForEach-Object { ($_ -split '[\\/]')[0] } |
    Group-Object |
    Sort-Object Name |
    ForEach-Object { Write-Output ("  {0,-28} {1} file(s)" -f $_.Name, $_.Count) }

if ($missingRequired.Count -gt 0 -and $AllowMissing) {
    Write-Warning "Required file(s) missing from this archive: $($missingRequired -join ', ')"
}
if ($flaggedNames.Count -gt 0) {
    Write-Warning "Filenames worth checking before publishing:"
    $flaggedNames | ForEach-Object { Write-Warning "  $_" }
}
if ($flaggedContent.Count -gt 0) {
    Write-Warning "Possible credentials found INSIDE archived files:"
    $flaggedContent | ForEach-Object { Write-Warning ("  {0}  [{1}]" -f $_.File, $_.Kind) }
    Write-Warning "Delete this archive, remove the secrets, rotate them, and rebuild."
}
if ($flaggedNames.Count -eq 0 -and $flaggedContent.Count -eq 0) {
    Write-Output ''
    Write-Output 'No suspicious filenames or credential patterns found.'
}
Write-Output ''
Write-Output 'Review the list above before publishing this archive.'
